package hashCode2020;

import java.util.ArrayList;
import java.util.Collections;

public class testing {
    public static void main(String[] args) {
        Book b = new Book(1,1);
        Book c = new Book(1,1);
        c.repe = true;

        ArrayList<Book> a = new ArrayList<>();
        a.add(b);
        a.add(c);

        Collections.sort(a);
        System.out.println(a);
    }
}
