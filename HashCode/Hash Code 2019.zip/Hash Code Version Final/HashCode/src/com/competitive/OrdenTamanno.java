package com.competitive;

public class OrdenTamanno {
    private String key;
    private int valor;

    public OrdenTamanno(String key, int valor) {
        this.key = key;
        this.valor = valor;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}

